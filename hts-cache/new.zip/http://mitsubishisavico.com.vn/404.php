
<!DOCTYPE html>

<html class="no-js" lang="en">

<head>
   <!-- Locale -->
   <meta http-equiv="Content-Language" content="en">

   <!-- To the Future! -->
   <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

   <!-- Meta -->
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
   <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
   <meta name="generator" content="">
   <meta name="description" content="">
   <meta name="keywords" content="" />
   <!-- Facebook Meta Tags -->
   <meta property="og:image" content="">
   <meta property="og:title" content="">
   <meta name="description" content="">
   <meta property="og:url" content="">
   <meta property="og:site_name" content="Mitsubishi Savico Đà Nẵng">
   <meta property="og:type" content="website">
   <title>
      Không tìm thấy trang | Mitsubishi Savico Đà Nẵng   </title>

   <!-- Favicons -->
   <link rel="icon" type="image/x-icon" href="/public/img/favicon.png">
   <link rel="shortcut icon" type="image/x-icon" href="/public/img/favicon.png">
   <link rel="apple-touch-icon" href="/public/img/favicon.png">

   <!-- style -->
   <!-- build:css css/combined.css -->
   <!--<link rel="stylesheet" href="/public/css/styles.css" />-->
   <link rel="stylesheet" href="/public/css/combined.css" />
   <script src="/public/js/vendor/jquery.js"></script>
   <!-- endbuild -->
   <!-- end style -->
   <!-- Google Tag Manager -->
    <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
    new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
    j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
    'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
    })(window,document,'script','dataLayer','GTM-KM6RQHD');</script>
    <!-- End Google Tag Manager -->
	<script async src="https://www.googletagmanager.com/gtag/js?id=AW-821377266"></script>
	<script>
	  window.dataLayer = window.dataLayer || [];
	  function gtag(){dataLayer.push(arguments);}
	  gtag('js', new Date());

	  gtag('config', 'AW-821377266');
	</script>
</head>

<body>
  <!-- Google Tag Manager (noscript) -->
  <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-KM6RQHD"
  height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
  <!-- End Google Tag Manager (noscript) -->

     <!-- header -->
   <header id="header" class="header">
      <div class="main-logo">
         <a target="_blank" href="http://www.mitsubishi-motors.com.vn/" title="Mitsubishi Motors Việt Nam">
            <img class="logo" alt="Mitsubishi Motors Việt Nam" src="/public/img/main-logo.svg">
         </a>
      </div>
      <div class="mb-menu">
         <div class="logo-satsco">
            <a href="/" title="MITSUBISHI SAVICO ĐÀ NẴNG" class="clearfix">
                                <img src="http://mitsubishisavico.com.vn/w/wp-content/uploads/2017/04/Logo.png" alt="MITSUBISHI SAVICO ĐÀ NẴNG" />
                             <div class="col">
                  <h2>MITSUBISHI SAVICO ĐÀ NẴNG</h2>
                  <span>02 Nguyễn Hữu Thọ, P.Hòa Thuận Tây, Q. Hải Châu, TP.Đà Nẵng</span>
               </div>
            </a>
         </div>
         <!-- Menu on top header: Top menu - Search - Language - Social-->
         <div class="top-header">
            <div class="header-inner clearfix" data-item="[
              {
                 &quot;caption&quot;: &quot;Bảng giá&quot;,
                 &quot;link&quot;: &quot;/bang-gia/&quot;,
                 &quot;newWindow&quot;: false,
                 &quot;internal&quot;: 1240,
                 &quot;edit&quot;: false,
                 &quot;isInternal&quot;: true,
                 &quot;internalName&quot;: &quot;Bảng giá&quot;,
                 &quot;type&quot;: &quot;internal&quot;,
                 &quot;title&quot;: &quot;Bảng giá&quot;
              },
              {
                 &quot;caption&quot;: &quot;Đăng ký lái thử&quot;,
                 &quot;link&quot;: &quot;/dang-ky-lai-thu/&quot;,
                 &quot;newWindow&quot;: false,
                 &quot;internal&quot;: 1487,
                 &quot;edit&quot;: false,
                 &quot;isInternal&quot;: true,
                 &quot;internalName&quot;: &quot;Đăng ký lái thử&quot;,
                 &quot;type&quot;: &quot;internal&quot;,
                 &quot;title&quot;: &quot;Đăng ký lái thử&quot;
              },
              {
                 &quot;caption&quot;: &quot;Hệ thống đại lý&quot;,
                 &quot;link&quot;: &quot;/dai-ly/&quot;,
                 &quot;newWindow&quot;: false,
                 &quot;internal&quot;: 1077,
                 &quot;edit&quot;: false,
                 &quot;isInternal&quot;: true,
                 &quot;internalName&quot;: &quot;Đại lý&quot;,
                 &quot;type&quot;: &quot;internal&quot;,
                 &quot;title&quot;: &quot;Hệ thống đại lý&quot;
              }
           ]" data-item-type="Newtonsoft.Json.Linq.JArray">
               <div class="search-box visible-xs">
                  <div class="search-toggle"></div>
                  <form id="search-form" name="search-form" class="search-form" action="" method="get" style="display: none;">
                     <input name="q" type="text" placeholder="Tìm kiếm" autocomplete="off" class="input search-input">
                     <button type="submit" title="Tìm kiếm" class="btn search-btn"><i class="fa fa-search"></i></button>
                  </form>
               </div>
               <ul class="contact-box hidden-xs">
                  <li>
                     Kinh doanh:
                     <a href="tel:0886.47.38.38"><strong>0886.47.38.38</strong></a>
                  </li>
                  <li>
                     Dịch vụ:
                     <a href="tel:0886.47.67.67"><strong>0886.47.67.67</strong></a>
                  </li>
               </ul>
            </div>
         </div>
         <!-- End - Menu on top header: Top menu - Search - Language - Social-->
         <!-- Main menu-->
         <nav role="navigation" class="main-nav">
            <button class="btn nav-toggle">
              <span class="line line-1"></span>
              <span class="line line-2"></span>
              <span class="line line-3"></span>
           </button>
            <div class="nav-container">
               <!-- <div class="social-top-header hidden-xs">
                 <a class="text" href="http://mitsubishi-motors.com.vn/">
                     <i class="fa fa-angle-double-right" aria-hidden="true"></i>
                 </a>
              </div> -->
               <ul class="nav-menu">
                  <li class="menu-item" data-menu="trang-chu">
                     <a href="/" title="TRANG CHỦ" class="menu-link">TRANG CHỦ</a>
                  </li>
                  <li class="menu-item" data-menu="gioi-thieu">
                     <a href="/gioi-thieu/" title="GIỚI THIỆU" class="menu-link">GIỚI THIỆU</a>
                  </li>
                  <li class="menu-item has-dropdown menu-item-sp" data-menu="san-pham">
                     <a href="javascript:;" title="SẢN PHẨM" class="menu-link">SẢN PHẨM</a>
                     <div class="nav-dropdown">
                        <div class="nav-dropdown-inner">
                           <ul class="menu">
                                                           <li class="menu-item">
                                 <a href="/san-pham/mirage/" title="Mirage" class="menu-link-sp">
                                    <div class="img">
                                       <img src="http://www.mitsubishi-motors.com.vn/w/wp-content/uploads/2017/05/mirage.png?width=400&height=160" alt="Mirage">
                                    </div>
                                    <div class="text">
                                       <span class="menu-title">Mirage</span>
                                       <span class="menu-price">Giá từ 381 triệu đồng</span>
                                    </div>
                                 </a>
                              </li>
                                                          <li class="menu-item">
                                 <a href="/san-pham/attrage/" title="Attrage" class="menu-link-sp">
                                    <div class="img">
                                       <img src="http://www.mitsubishi-motors.com.vn/w/wp-content/uploads/2017/05/attrage.png?width=400&height=160" alt="Attrage">
                                    </div>
                                    <div class="text">
                                       <span class="menu-title">Attrage</span>
                                       <span class="menu-price">Giá từ 396 triệu đồng</span>
                                    </div>
                                 </a>
                              </li>
                                                          <li class="menu-item">
                                 <a href="/san-pham/outlander/" title="Outlander" class="menu-link-sp">
                                    <div class="img">
                                       <img src="http://www.mitsubishi-motors.com.vn/w/wp-content/uploads/2017/05/outlander.png?width=400&height=160" alt="Outlander">
                                    </div>
                                    <div class="text">
                                       <span class="menu-title">Outlander</span>
                                       <span class="menu-price">Giá từ 808 triệu đồng</span>
                                    </div>
                                 </a>
                              </li>
                                                          <li class="menu-item">
                                 <a href="/san-pham/pajero-sport/" title="Pajero Sport" class="menu-link-sp">
                                    <div class="img">
                                       <img src="http://www.mitsubishi-motors.com.vn/w/wp-content/uploads/2017/05/new-pajero-sport.png?width=400&height=160" alt="Pajero Sport">
                                    </div>
                                    <div class="text">
                                       <span class="menu-title">Pajero Sport</span>
                                       <span class="menu-price">Giá từ 1.062 tỉ đồng</span>
                                    </div>
                                 </a>
                              </li>
                                                          <li class="menu-item">
                                 <a href="/san-pham/triton/" title="Triton" class="menu-link-sp">
                                    <div class="img">
                                       <img src="http://www.mitsubishi-motors.com.vn/w/wp-content/uploads/2017/05/triton.png?width=400&height=160" alt="Triton">
                                    </div>
                                    <div class="text">
                                       <span class="menu-title">Triton</span>
                                       <span class="menu-price">Giá từ 556 triệu đồng</span>
                                    </div>
                                 </a>
                              </li>
                                                          <li class="menu-item">
                                 <a href="/san-pham/all-new-xpander1/" title="All New Xpander" class="menu-link-sp">
                                    <div class="img">
                                       <img src="http://www.mitsubishi-motors.com.vn/w/wp-content/uploads/2018/08/xpander.png?width=400&height=160" alt="All New Xpander">
                                    </div>
                                    <div class="text">
                                       <span class="menu-title">All New Xpander</span>
                                       <span class="menu-price">Giá từ - triệu đồng</span>
                                    </div>
                                 </a>
                              </li>
                                                       </ul>
                        </div>
                     </div>
                  </li>
                  <li class="menu-item" data-menu="bang-gia">
                     <a href="/bang-gia/" title="BẢNG GIÁ XE & KHUYẾN MÃI" class="menu-link">BẢNG GIÁ XE & KHUYẾN MÃI</a>
                  </li>
                  <!-- <li class="menu-item" data-menu="khuyen-mai">
                     <a href="/khuyen-mai/" title="KHUYẾN MÃI" class="menu-link">KHUYẾN MÃI</a>
                  </li> -->
                  <li class="menu-item has-dropdown" data-menu="mua-xe">
                     <a href="javascript:;" title="MUA XE" class="menu-link">MUA XE</a>
                     <div class="nav-dropdown">
                        <ul class="nav-dropdown-menu">
                           <li class="nav-dropdown-item">
                              <a href="/mua-xe/mua-xe-tra-gop/" title="Mua xe trả góp" class="nav-dropdown-link">Mua xe trả góp</a>
                           </li>
                           <li class="nav-dropdown-item">
                              <a href="/mua-xe/mua-xe-theo-lo/" title="Mua xe theo lô" class="nav-dropdown-link">Mua xe theo lô</a>
                           </li>
                           <li class="nav-dropdown-item">
                              <a href="/mua-xe/quy-trinh-mua-xe/" title="Quy trình mua xe" class="nav-dropdown-link">Quy trình mua xe</a>
                           </li>
                           <li class="nav-dropdown-item">
                              <a href="/mua-xe/dang-ky-lai-thu/" title="Đăng ký lái thử" class="nav-dropdown-link">Đăng ký lái thử</a>
                           </li>
                           <li class="nav-dropdown-item">
                              <a href="/mua-xe/bao-gia-chi-tiet/" title="Báo giá chi tiết" class="nav-dropdown-link">Báo giá chi tiết</a>
                           </li>
                        </ul>
                     </div>
                  </li>
                  <li class="menu-item has-dropdown" data-menu="dich-vu-hau-mai">
                     <a href="javascript:;" title="DỊCH VỤ HẬU MÃI" class="menu-link">DỊCH VỤ HẬU MÃI</a>
                     <div class="nav-dropdown">
                        <ul class="nav-dropdown-menu">
                           <li class="nav-dropdown-item">
                              <a href="/dich-vu-hau-mai/gioi-thieu-dich-vu/" title="Giới thiệu dịch vụ" class="nav-dropdown-link">Giới thiệu dịch vụ</a>
                           </li>
                           <li class="nav-dropdown-item">
                              <a href="/dich-vu-hau-mai/bao-duong-dinh-ky/" title="Bảo dưỡng định kỳ" class="nav-dropdown-link">Bảo dưỡng định kỳ</a>
                           </li>
                           <li class="nav-dropdown-item">
                              <a href="/dich-vu-hau-mai/sua-chua/" title="Sửa chữa" class="nav-dropdown-link">Sửa chữa</a>
                           </li>
                           <!-- <li class="nav-dropdown-item">
                              <a href="/dich-vu-hau-mai/cuu-ho-giao-thong/" title="Cứu hộ giao thông" class="nav-dropdown-link">Cứu hộ giao thông</a>
                           </li> -->
                           <li class="nav-dropdown-item">
                              <a href="/dich-vu-hau-mai/chinh-sach-bao-hanh/" title="Chính sách bảo hành" class="nav-dropdown-link">Chính sách bảo hành</a>
                           </li>
                           <li class="nav-dropdown-item">
                              <a href="/dich-vu-hau-mai/phu-tung-chinh-hieu/" title="Phụ tùng chính hiệu" class="nav-dropdown-link">Phụ tùng chính hiệu</a>
                           </li>
                           <li class="nav-dropdown-item">
                              <a href="/dich-vu-hau-mai/dat-lich-bao-duong/" title="Đặt lịch bảo dưỡng" class="nav-dropdown-link">Đặt lịch bảo dưỡng</a>
                           </li>
                        </ul>
                     </div>
                  </li>
                  <li class="menu-item has-dropdown" data-menu="tin-tuc">
                     <a href="javascript:;" title="TIN TỨC" class="menu-link">TIN TỨC</a>
                     <div class="nav-dropdown">
                        <ul class="nav-dropdown-menu">

                          
                           <li class="nav-dropdown-item">
                              <a href="/tin-tuc/su-kien-noi-bat-c2/" title="Sự kiện nổi bật" class="nav-dropdown-link">Sự kiện nổi bật</a>
                           </li>
                           
                           <li class="nav-dropdown-item">
                              <a href="/tin-tuc/tin-khuyen-mai-c5/" title="Tin khuyến mãi" class="nav-dropdown-link">Tin khuyến mãi</a>
                           </li>
                           
                           <li class="nav-dropdown-item">
                              <a href="/tin-tuc/tin-tong-hop-c3/" title="Tin tổng hợp" class="nav-dropdown-link">Tin tổng hợp</a>
                           </li>
                           
                           <li class="nav-dropdown-item">
                              <a href="/tin-tuc/tin-tuyen-dung-c4/" title="Tin tuyển dụng" class="nav-dropdown-link">Tin tuyển dụng</a>
                           </li>
                           
                        </ul>
                     </div>
                  </li>
                  <li class="menu-item" data-menu="lien-he">
                     <a href="/lien-he/" title="LIÊN HỆ" class="menu-link">LIÊN HỆ</a>
                  </li>
                  <li class="menu-item">
                     <ul class="social-box">
                        <li>
                           <a href="https://www.facebook.com/mitsubishisavicodanangcity/" title="Facebook" class="icon-social facebook" target="_blank">
                              <i class="fa fa-facebook"></i>
                           </a>
                        </li>
                        <li>
                           <a href="https://www.youtube.com/watch?v=lG_kak_P-bo&t=25s" title="Youtube" class="icon-social youtube" target="_blank">
                              <i class="fa fa-youtube-play"></i>
                           </a>
                        </li>
                     </ul>
                  </li>
               </ul>
               <div class="social-top-header visible-xs">
                  <a class="text" href="/">
                    Về trang Mitsubishi Motors Việt Nam <i class="fa fa-angle-double-right" aria-hidden="true"></i>
                 </a>
               </div>
            </div>
         </nav>
      </div>
   </header>
   <!-- end header -->

<section id="err_404">
   <picture>
       <source media="(max-width: 991px)" srcset="/public/img/404-banner-dt.jpg">
       <source media="(min-width: 992px)" srcset="/public/img/404-banner-dt.jpg">
       <img class="img-full" src="/public/img/404-banner-dt.jpg" alt="">
   </picture>
</section>
<!-- block contact -->
<div id="blockcontact" class="scroll">
   <ul class="block-contact visible-xs">
      <li>
         Hotline kinh doanh:
         <strong><a href="tel:0886.47.38.38">0886.47.38.38</a></strong>
      </li>
      <li>
         Hotline dịch vụ:
         <strong><a href="tel:0886.47.67.67">0886.47.67.67</a></strong>
      </li>
   </ul>
</div>
<!-- end block content -->

<!-- footer -->
<footer id="footer" class="footer">
   <div class="footer-satsco hidden-xs">
      <div class="grid-inner">
         <div class="img">
            <img src="http://mitsubishisavico.com.vn/w/wp-content/uploads/2017/04/Logo.png" alt="" />
         </div>
         <div class="text">
            <strong>Mitsubishi Savico Đà Nẵng</strong> 02 Nguyễn Hữu Thọ, P.Hòa Thuận Tây, Q. Hải Châu, TP.Đà Nẵng         </div>
      </div>
   </div>

   <div class="footer-top">
      <div class="grid-inner">
         <ul class="footer-top-list">
            <li>
               <a href="/bang-gia/" title="Bảng giá xe" class="left-icon-link">
                  <span class="icon">
                     <i class="svg-icon svg-icon icon-price red red "></i>
                  </span>
                  <span class="text">Bảng giá xe</span>
               </a>
            </li>
            <li>
               <a href="/khuyen-mai/" title="Khuyến mãi" class="left-icon-link">
                  <span class="icon">
                     <i class="svg-icon svg-icon icon-promotion red red "></i>
                  </span>
                  <span class="text">Khuyến mãi</span>
               </a>
            </li>
            <li>
               <a href="/mua-xe/dang-ky-lai-thu/" title="Đăng ký lái thử" class="left-icon-link">
                  <span class="icon">
                     <i class="svg-icon svg-icon icon-drive red red "></i>
                  </span>
                  <span class="text">Đăng ký lái thử</span>
               </a>
            </li>
         </ul>

         <div class="footer-top-contact">
            <div class="left-icon-link link-satsco hidden-sm hidden-md hidden-lg">
               <div class="icon">

               </div>
               <div class="text">
                  <span>MITSUBISHI SAVICO ĐÀ NẴNG</span>
                  <strong><span>02 Nguyễn Hữu Thọ, P.Hòa Thuận Tây, Q. Hải Châu, TP.Đà Nẵng</span></strong>
               </div>
            </div>
            <div class="left-icon-link">
               <div class="icon">
                  <i class="svg-icon icon-phone-small"></i>
               </div>
               <div class="text">
                  <span>HOTLINE ( 7h30 – 20h00 )</span>
                  <strong><span>Kinh doanh:</span> <a href="tel:0886.47.38.38">0886.47.38.38</a></strong>
                  <strong><span>Dịch vụ:</span> <a href="tel:0886.47.67.67">0886.47.67.67</a></strong>
               </div>
            </div>
         </div>

         <ul class="social-box hidden-xs">
            <li>
               <a href="https://www.facebook.com/mitsubishisavicodanangcity/" title="Facebook" class="icon-social facebook" target="_blank">
                  <i class="fa fa-facebook"></i>
               </a>
            </li>
            <li>
               <a href="https://www.youtube.com/watch?v=lG_kak_P-bo&t=25s" title="Youtube" class="icon-social youtube" target="_blank">
                  <i class="fa fa-youtube-play"></i>
               </a>
            </li>
         </ul>
      </div>
   </div>

   <div class="footer-middle hidden-xs">
      <div class="grid-inner">
         <div class="footer-middle-col">
            <a href="/">
               <h3 class="bold-title">TRANG CHỦ</h3>
            </a>
            <ul class="normal-list">
               <li><a href="/gioi-thieu/" title="Giới thiệu">Giới thiệu</a></li>
               <li><a href="/bang-gia/" title="Bảng giá">Bảng giá</a></li>
               <li><a href="/khuyen-mai/" title="Khuyến mãi">Khuyến mãi</a></li>
               <li><a href="/lien-he/" title="Liên hệ">Liên hệ</a></li>
            </ul>
         </div>
         <div class="footer-middle-col">
            <h3 class="bold-title">SẢN PHẨM</h3>
            <ul class="normal-list">
                             <li><a href="/san-pham/mirage/" title="Mirage">Mirage</a></li>
                             <li><a href="/san-pham/attrage/" title="Attrage">Attrage</a></li>
                             <li><a href="/san-pham/outlander/" title="Outlander">Outlander</a></li>
                             <li><a href="/san-pham/pajero-sport/" title="Pajero Sport">Pajero Sport</a></li>
                             <li><a href="/san-pham/triton/" title="Triton">Triton</a></li>
                             <li><a href="/san-pham/pajero1/" title="Pajero">Pajero</a></li>
                             <li><a href="/san-pham/all-new-xpander1/" title="All New Xpander">All New Xpander</a></li>
                             <li><a href="/san-pham/outlander-sport/" title="Outlander Sport">Outlander Sport</a></li>
                             <li><a href="/san-pham/pajero-sport1/" title="Pajero Sport1">Pajero Sport1</a></li>
                          </ul>
         </div>
         <div class="footer-middle-col">
            <h3 class="bold-title">MUA XE</h3>
            <ul class="normal-list">
               <li><a href="/mua-xe/mua-xe-tra-gop/" title="Mua xe trả góp">Mua xe trả góp</a></li>
               <li><a href="/mua-xe/mua-xe-theo-lo/" title="Mua xe theo lô">Mua xe theo lô</a></li>
               <li><a href="/mua-xe/quy-trinh-mua-xe/" title="Quy trình mua xe ">Quy trình mua xe </a></li>
               <li><a href="/mua-xe/dang-ky-lai-thu/" title="Đăng ký lái thử">Đăng ký lái thử</a></li>
               <li><a href="/mua-xe/bao-gia-chi-tiet/" title="Báo giá chi tiết">Báo giá chi tiết</a></li>
            </ul>
         </div>
         <div class="footer-middle-col">
            <h3 class="bold-title">DỊCH VỤ HẬU MÃI</h3>
            <ul class="normal-list">
               <li><a href="/dich-vu-hau-mai/gioi-thieu-dich-vu/" title="Giới thiệu dịch vụ">Giới thiệu dịch vụ</a></li>
               <li><a href="/dich-vu-hau-mai/bao-duong-dinh-ky/" title="Bảo dưỡng định kỳ">Bảo dưỡng định kỳ</a></li>
               <li><a href="/dich-vu-hau-mai/sua-chua/" title="Sửa chữa">Sửa chữa</a></li>
               <li><a href="/dich-vu-hau-mai/cuu-ho-giao-thong/" title="Cứu hộ giao thông">Cứu hộ giao thông</a></li>
               <li><a href="/dich-vu-hau-mai/chinh-sach-bao-hanh/" title="Chính sách bảo hành">Chính sách bảo hành</a></li>
               <li><a href="/dich-vu-hau-mai/phu-tung-chinh-hieu/" title="Phụ tùng chính hiệu">Phụ tùng chính hiệu</a></li>
               <li><a href="/dich-vu-hau-mai/dat-lich-bao-duong/" title="Đặt lịch bảo dưỡng">Đặt lịch bảo dưỡng</a></li>
            </ul>
         </div>
         <div class="footer-middle-col">
            <h3 class="bold-title">TIN TỨC</h3>
            <ul class="normal-list">
                             <li><a href="/tin-tuc/su-kien-noi-bat-c2/" title="Sự kiện nổi bật">Sự kiện nổi bật</a></li>
                             <li><a href="/tin-tuc/tin-khuyen-mai-c5/" title="Tin khuyến mãi">Tin khuyến mãi</a></li>
                             <li><a href="/tin-tuc/tin-tong-hop-c3/" title="Tin tổng hợp">Tin tổng hợp</a></li>
                             <li><a href="/tin-tuc/tin-tuyen-dung-c4/" title="Tin tuyển dụng">Tin tuyển dụng</a></li>
                          </ul>
         </div>
      </div>
   </div>

   <div class="footer-bottom">
      <div class="inner">
         <div class="copyright">©2018 Bản quyền thuộc về Mitsubishi Motors Vietnam Co.,Ltd.</div>
      </div>
   </div>
</footer>
<!-- end footer -->

<!-- floating menu -->
<ul class="float-menu-block">
   <li>
      <a href="/bang-gia/" alt="Bảng giá" class="left-icon-item">
         <span class="icon"><i class="svg-icon icon-price smoke"></i></span>
         <span class="text">Bảng giá</span>
      </a>

   </li>
   <li>
      <a href="/khuyen-mai/" alt="Khuyến mãi" class="left-icon-item">
         <span class="icon"><i class="svg-icon icon-promotion smoke"></i></span>
         <span class="text">Khuyến mãi</span>
      </a>
   </li>
   <li>
      <a href="/mua-xe/dang-ky-lai-thu/" alt="" class="left-icon-item">
         <span class="icon"><i class="svg-icon icon-drive smoke"></i></span>
         <span class="text">Đăng ký lái thử</span>
      </a>
   </li>
   <!-- <li>
      <a href="javascript:;" alt="Đại lý" class="left-icon-item">
         <span class="icon"><i class="svg-icon icon-dealer smoke"></i></span>
         <span class="text">Hệ thống đại lý</span>
      </a>
   </li> -->
</ul>
<!-- end floating menu -->

<!-- scripts -->
<!-- build:js scripts/combined.js -->
<!-- jQuery -->
<!--<script src="/public/js/vendor/jquery.js"></script>-->
<!-- end jQuery -->
<!--
<script src="/public/js/vendor/tether.js"></script>
<script src="/public/js/vendor/bootstrap.js"></script>
<script src="/public/js/vendor/jquery-ui.min.js"></script>
<script src="/public/js/vendor/picturefill.js"></script>
<script src="/public/js/vendor/threesixty.js"></script>
<script src="/public/js/vendor/greensock-js/TimelineMax.min.js"></script>
<script src="/public/js/vendor/greensock-js/TweenMax.min.js"></script>
<script src="/public/js/vendor/greensock-js/plugins/ScrollToPlugin.min.js"></script>
<script src="/public/js/vendor/jquery.fancybox.js"></script>
<script src="/public/js/vendor/jquery.mCustomScrollbar.js"></script>
<script src="/public/js/vendor/jquery.fs.selecter.min.js"></script>
<script src="/public/js/vendor/enscroll.min.js"></script>
<script src="/public/js/vendor/slick.js"></script>
<script src="/public/js/theme/main.js"></script>
<script src="/public/js/theme/ajax.js"></script>
<script src="/public/js/theme/modal.js"></script>
<script src="/public/js/theme/validate-dat-lich.js"></script>
<script src="/public/js/theme/validate-form.js"></script>
-->
<!-- endbuild -->

<!--<script src="/public/js/theme/home-page.js"></script>-->

<!-- end scripts -->
<script src="/public/js/theme/combined.js"></script>

<script>
  //1
   $(function() {
      $(".picker").datepicker({
         dateFormat: "dd-mm-yy",
      });
   });
   
   //2
  $('#BlockNews').html($('#dealernews').html());
  $('.phienban-btn li:eq(3)').hide();

  var carid = $('.phienban-btn li:eq(0) a').attr('data-car-id');
  var linklaithu = "/mua-xe/dang-ky-lai-thu/" + carid + "/";
  var linkbaogia = "/mua-xe/bao-gia-chi-tiet/" + carid + "/";
  $('.phienban-btn li:eq(2) a').attr('href', linklaithu);
  $('.phienban-btn li:eq(1) a').attr('href', linkbaogia);
  $('.phienban-btn li:eq(1) a').removeAttr('data-estimate-url');
  $('.phienban-btn li:eq(1) a').unbind().bind('click', function(e){
    //e.preventdefault();
    window.location = $(this).attr('href');
  });
  productInit();

  //3
  var productApi = null;
  getProductApi();
  function getProductApi() {
    var url = 'http://mitsubishi-motors.com.vn/api/getProductFromDealer.php';
    $.get(url, function(response) {
      if (!response.HasError) {
        productApi = response.Data;
        getProductLayout();
      } else {
        console.error(response.Error);
      }
    })
  }
  function getProductLayout() {
    if (productApi) {
      var url = productApi[0].Url;
      $('#product_main').load(url, function() {
        runningProductInit();
      })
    }
  }
  function runningProductInit() {
    if (typeof productInit != 'undefined') {
        productInit();
    }
    else {
        setTimeout(runningProductInit, 100);
    }
  }
</script>

</body>

</html>
